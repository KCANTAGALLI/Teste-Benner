# MicroOndasDigital
Projeto de um micro ondas digital em Windows Form.

Aqui utilizei um pouco de orientação a objeto, SOLID e com Windows Form Application.

##Teste Para empresa Benner

##Desenvolvedor: Kleber Guido Dutra Cantagalli
