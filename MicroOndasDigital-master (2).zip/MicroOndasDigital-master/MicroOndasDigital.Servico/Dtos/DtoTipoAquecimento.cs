﻿namespace MicroOndasDigital.Servico.Dtos
{
    public class DtoTipoAquecimento : DtoMicroOndasDigital
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}
