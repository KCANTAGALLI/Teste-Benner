﻿namespace MicroOndasDigital.Servico.Dtos
{
    public class DtoMicroOndasDigital
    {
        public int Tempo { get; set; }

        public int Potencia { get; set; }

        public bool EhValido { get; set; }

        public string Mensagem { get; set; }
    }
}
